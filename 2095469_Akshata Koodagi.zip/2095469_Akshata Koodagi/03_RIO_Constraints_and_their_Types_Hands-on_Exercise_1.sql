-- excreise 3.1 .
use trainer_info;
ALTER TABLE trainer_info add primary key (trainer_id);

use trainer_info;
alter table trainer_info add check (trainer_id like "f%");

select * from trainer_info;
alter table trainer_info modify trainer_id varchar(20) not null;
alter table trainer_info modify salutation varchar(7) not null;
alter table trainer_info modify trainer_name varchar(30) not null;
alter table trainer_info modify trainer_location varchar(30) not null;
alter table trainer_info modify trainer_track varchar(15) not null;
alter table trainer_info modify trainer_qualification varchar(100) not null;
alter table trainer_info modify trainer_email varchar(100) not null;
alter table trainer_info modify trainer varchar(20) not null;

use batch_info;
alter table batch_info add primary key (batch_id);
alter table batch_info modify batch_id varchar(20) not null;
alter table batch_info modify batch_owner varchar(30) not null;
alter table batch_info modify batch_bu_name varchar(20) not null;
alter table batch_info add check (batch_id like "b%");

use module_info;
alter table module_info add primary key (module_id);
alter table module_info modify module_id varchar(20) not null;
alter table module_info modify module_duration int not null;
alter table module_info modify module_name varchar(40) not null;
alter table module_info add check (binary module_id <> binary lower (module_id));

use associate_info;
alter table associate_info add primary key (associate_id);
alter table associate_info add check (associate_id like "a%");
alter table associate_info modify associate_id varchar(20) not null;
alter table associate_info modify salutation varchar(7) not null;
alter table associate_info modify associate_name varchar(30) not null;
alter table associate_info modify associate_location varchar(30) not null;
alter table associate_info modify associate_track varchar(15) not null;
alter table associate_info modify associate_qualification varchar(100) not null;
alter table associate_info modify associate_email varchar(100) not null;
alter table associate_info modify associate_password varchar(20) not null;

use questions;
alter table questions add primary key (question_id);
alter table questions add foreign key (module_id) references module_info (module_id);
alter table questions modify questions_text varchar(900) not null;

use associate_status;
select *from associate_info;
alter table associate_status add foreign key (associate_id) references associate_info (associate_id);
alter table associate_status add foreign key (module_id) references module_info (module_id);
alter table associate_status add foreign key (batch_id) references batch_info (batch_id);
alter table associate_status add foreign key (trainer_id) references trainer_info (trainer_id);
alter table associate_status modify associate_id varchar(20) not null;
alter table associate_status modify module_id varchar(20) not null;
alter table associate_status modify batch_id varchar(20) not null;
alter table associate_status modify trainer_id varchar(20) not null;

use trainer_feedback;

alter table trainer_feedback add foreign key (trainer_id) references trainer_info (trainer_id);
alter table trainer_feedback add foreign key (question_id) references questions (question_id);
alter table trainer_feedback add foreign key (batch_id) references batch_info (batch_id);
alter table trainer_feedback add foreign key (module_id) references module_info (module_id);
alter table trainer_feedback modify trainer_id varchar(20) not null;
alter table trainer_feedback modify question_id varchar(20) not null;
alter table trainer_feedback modify batch_id varchar(20) not null;
alter table trainer_feedback modify module_id varchar(20) not null;
alter table trainer_feedback modify trainer_rating smallint not null;

use associate_feedback;
alter table associate_feedback add foreign key (associate_id) references associate_status (associate_id);
alter table associate_feedback add foreign key (question_id) references questions (question_id);
alter table associate_feedback add foreign key (module_id) references module_info (module_id);
alter table associate_feedback modify associate_id varchar(20) not null;
alter table associate_feedback modify question_id varchar(20) not null;
alter table associate_feedback modify module_id varchar(20) not null;
alter table associate_feedback modify associate_rating smallint not null;

-- excreise 3.2
create table product(product_id int primary key,product_name varchar(20),product_price int not null);
create table username(user_id varchar(10) primary key ,product_id int,username varchar(20),foreign key (product_id)references product(product_id));

insert into product values (1,'A Dongle',290),(2,'B Dongle',1250);
insert into product(product_id,product_name) values (3,'C Dongle');
select * from product;

set foreign_key_check =1;
select * from username;
drop table username;
insert into username(user_id,product_id,username) values ('U001',1,'Ramesh'),('U002',11,'Mahesh');