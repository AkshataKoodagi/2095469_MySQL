create database trainer_info;
use trainer_info;
create table trainer_info(trainer_id varchar(20),salutation varchar(7),trainer_name varchar(30),trainer_location varchar(30),
trainer_track varchar(15),trainer_qualification varchar(100),trainer_expirence int,trainer_email varchar(100),trainer varchar(100));

create database Batch_info;
use batch_info;

create table Batch_info(Batch_id varchar(20),Batch_Owner varchar(30),Batch_BU_Name varchar(30));
create database Module_info;
use Module_info;

create table Module_info(Module_id varchar(20),Module_name Varchar(40),Module_duration int);

create database Associate_info;
use Associate_info;

create table Associate_info(Associate_id varchar(20),salutation varchar(7),Associate_name varchar(30),Associate_location varchar(30),
Associate_track varchar(15),Associate_qualification varchar(200),Associate_Email varchar(100),Associate_password varchar(20));

create database Questions;
use Questions;

create table Questions(Question_id varchar(20),Module_id varchar(20),Questions_text varchar(900));

create database Associate_status;
use Associate_status;

create table Associate_status(Associate_id varchar(20),Module_id varchar(20),Start_date varchar(20),End_date varchar(20),
AFeedbackGiven varchar(20),TFeedbackGiven varchar(20));

create database trainer_feedback;
use trainer_feedback;

create table trainer_feedback(trainer_id varchar(20),question_id varchar(20),batch_id varchar(20),Module_id varchar(20),
Trainer_rating int);

create database Associate_Feedback;
use Associate_feedback;

create table Associate_feedback(Associate_id varchar(20),Question_id varchar(20),Module_id varchar(20),Associate_rating int);

create database Login_details;
use Login_details;

create table Login_details(User_id varchar(20),User_password varchar(20));

use associate_status;

alter table associate_status add( batch_id varchar(20),trainer_id varchar(20));

use trainer_info;
insert into trainer_info values('F001','Mr.','PANKAJ GOSH','Pune','java','Bachelor of technology',12,'Pankaj.Gosh@alliance.com','fac1@123');
insert into trainer_info values('F002','Mr.','Sanjay Radhakrishnan','Banglore','dotnet','Bachelor of technlgy',12,'Sanjay.Radhakrishanan@alliance.com',
'fac2@123');
insert into trainer_info values('F003','Mr.','Vijay Mathur','Chennai','Mainframe','Bachelor of technlgy',10,'Vijay.Mathu@alliance.com',
'fac3@123');
insert into trainer_info values('F004','Mrs.','Nandini Nair','Kolkata','Java','Master of Computer Application',9,'Nandini.Nair@alliance.com',
'fac4@123');
insert into trainer_info values('F005','Miss.','ANITHA PAREKH','Hyderabad','testing','Maaster of Computer Application',6,'Anitha.parkesh@alliance.com','fac5@123');
insert into trainer_info values('F006','Mr.','MANOJ AGARWAL','Mumbai','Mainframe','Bachelor of technlgy',9,'Manoj.Agarwal@alliance.com',
'fac6@123');
insert into trainer_info values('F007','Ms.','MEENA KULKARNI','Chennai','Testing','Bachelor of technlgy',5,'Meena.Kulkarni@alliance.com',
'fac7@123');

use batch_info;
insert into batch_info values('B001','MRS.SWATI ROY','MSP');
insert into batch_info values('B002','MRS.ARUNA K','HEALTHCARE');
insert into batch_info values('B003','MR.RAJESH KRISHNAN','LIFE SCIENCES');
insert into batch_info values('B004','MR.SACHIN SHETTY','BFS');
insert into batch_info values('B005','MR.RAMESH PATEL','COMMUNICATION');
insert into batch_info values('B006','MRS. SUSAN CHERIAN','RETAIL&HOSPITALITY');
insert into batch_info values('B007','MRS.SAMPADA JAIN','MSP');
insert into batch_info values('B008', 'MRS.KAVITA REGE','BPO');
insert into batch_info values('B009','MRS.RAVI SEJPAL','MSP');

use module_info;
insert into module_info values('O10SQL','Oracle10g',16);
insert into module_info values('O10PLSQL','Orcale10g PL /SQL',16);
insert into module_info values('J2SE','Core Java SE 1.6',288);
insert into module_info values('J2EE','Advanced Java EE 1.6',80);
insert into module_info values('JAVAFX','JavaFX 2.1',80);
insert into module_info values('DOTNT4','Net Framework4.0',200);
insert into module_info values('SQL2008','MS SQL Server 2008',120);
insert into module_info values('MSBI08','MS BI Studio 2008',158);
insert into module_info values('SHRPNT','MS Share Point',80);
insert into module_info values('ANDRD4','Android 4.0',200);
insert into module_info values('EM001','Instructor',0);
insert into module_info values('EM002','Course Material',0);
insert into module_info values('EM003','Learning Effectiveness',0);
insert into module_info values('EMP004','Environment',0);
insert into module_info values('EMP005','Job Impact',0);
insert into module_info values('TM001','Attendees',0);

UPDATE module_info
set Module_duration=50
where Module_id= 'DOTNT4';

use module_info;
insert into module_info values('TM003','Environment',0);

use associate_info;


insert into associate_info values('A001','MISS.','GAYATHRI NARAYANAN','Gurgaon','Java','Bachelor of Technology',
'Gayathri.Nayaranan@hp.com','tne1@123');
insert into associate_info values('A002','MRS.','RADHA MOOHAN','Kerala','Java','Bachelor of Engineering in Information',
'Radha.Mohan@cognizant.com','tne2@123');
insert into associate_info values('A003','MR.','KISHOR SHRINIVAS','Chennai','Java','Bachelor of Engineering in Computers',
'Kishor.shrinivas@ibm.com','tne3@123');
insert into associate_info values('A004','MR.','ANAND RANGANATHAN','Mumbai','DotNet','Master of Computer Application',
'Anand.Ranganathan@finolex.com','tne4@123');
insert into associate_info values('A005','MISS.','LEELA MENON','Kerala','Mainframe','Bachelor of Engineering inInformation',
'Leela.Menon@microsoft.com','tne5@123');
insert into associate_info values('A006','MRS.','ARTI KRISHANAN','Pune','Testing','Master of Computer Application',
'Arti.Krishanann@cognizant.com','tne6@123');
insert into associate_info values('A007','MR.','PRABHAKAR SHUNMUGHAM','Mumbai','Java','Bachelor of Technology',
'Prabhakar.Shunmugham@honda.com','tne7@123');

use questions;

insert into questions values ('Q001','EM001','Instructor knowledgeable and able to handle all quires');
insert into questions values ('Q002','EM001','All thr topics in particular course handled by the trainer without any gap or slippages');
insert into questions values ('Q003','EM002','The course material presentation,hands on, etc. refered during the training are relavant and useful.');
insert into questions values ('Q004','EM002','The Hands on session adequate enough to grasp the understandingof the topic ');
insert into questions values ('Q005','EM002','The reference material for suggested for each module are adequate');
insert into questions values ('Q006','EM003','Knowledge and skills present in this training are applicable at your work');
insert into questions values ('Q007','EM003','This training increases my proficiency level');
insert into questions values ('Q008','EM004','The physical environment e.g. classroom space ,airconditioning was conducive to learning');
insert into questions values ('Q009','EM004','The software/hardware wnvironment provided was sufficient for the purpose of training');
insert into questions values ('Q010','EM005','This training will improve your job performance');
insert into questions values ('Q011','EM005','This training allign with business priorities and goals');
insert into questions values ('Q012','TM001','Participants were receptive and had attitude towards reading');
insert into questions values ('Q013','TM001','All participant gained the knowledge and the practical skills after this training');
insert into questions values ('Q014','TM002','The cours material presentation and etc. available for the session covers the entire objectives of the course');
insert into questions values ('Q015','TM002','Complexcity of the course is adequate for the practice level');
insert into questions values ('Q016','TM002','Case study and practical demos helpful in understanding of the topic');
insert into questions values ('Q017','TM003','The physical environment e.g. classroom space ,air conditioning was conducive to learning');
insert into questions values ('Q018','TM003','The softwaer/hardware environment provided was adequate for the purpose of training');

use associate_status;
insert into associate_status(Associate_id,Module_id,batch_id,trainer_id,Start_date,End_date) value ('A001','O10SQL','B001','FOO1','2000-12-15','2000-12-25');
insert into associate_status(Associate_id,Module_id,batch_id,trainer_id,Start_date,End_date) value ('A002','O10SQL','B001','FOO1','2000-12-15','2000-12-25');
insert into associate_status(Associate_id,Module_id,batch_id,trainer_id,Start_date,End_date) value ('A003','O10SQL','B001','FOO1','2000-12-15','2000-12-25');
insert into associate_status(Associate_id,Module_id,batch_id,trainer_id,Start_date,End_date)value ('A001','O10PLSQL','B002','F002','2001-2-1','2001-2-12');
insert into associate_status(Associate_id,Module_id,batch_id,trainer_id,Start_date,End_date)value ('A002','O10PLSQL','B002','F002','2001-2-1','2001-2-12');
insert into associate_status(Associate_id,Module_id,batch_id,trainer_id,Start_date,End_date) value ('A003','O10PLSQL','B002','F002','2001-2-1','2001-2-12');
insert into associate_status(Associate_id,Module_id,batch_id,trainer_id,Start_date,End_date) value ('A001','J2SE','B003','F003','2002-08-20','2002-10-25');
insert into associate_status(Associate_id,Module_id,batch_id,trainer_id,Start_date,End_date) value ('A002','J2SE','B003','F003','2002-08-20','2002-10-25');
insert into associate_status(Associate_id,Module_id,batch_id,trainer_id,Start_date,End_date) value ('A001','J2EE','B004','F004','2005-12-1','2005-12-20');
insert into associate_status(Associate_id,Module_id,batch_id,trainer_id,Start_date,End_date) value ('A002','J2EE','B004','F004','2005-12-1','2005-12-20');
insert into associate_status(Associate_id,Module_id,batch_id,trainer_id,Start_date,End_date) value ('A003','J2EE','B004','F004','2005-12-1','2005-12-20');
insert into associate_status(Associate_id,Module_id,batch_id,trainer_id,Start_date,End_date) value ('A004','J2EE','B004','F004','2005-12-1','2005-12-20');
insert into associate_status(Associate_id,Module_id,batch_id,trainer_id,Start_date,End_date) value ('A005','JAVAFX','B005','F006','2005-12-71','2005-12-20');
insert into associate_status(Associate_id,Module_id,batch_id,trainer_id,Start_date,End_date) value ('A006','JAVAFX','B005','F006','2005-12-71','2005-12-20');
insert into associate_status(Associate_id,Module_id,batch_id,trainer_id,Start_date,End_date) value ('A006','SQL2008','B006','F007','2007-06-12','2007-06-28');
insert into associate_status(Associate_id,Module_id,batch_id,trainer_id,Start_date,End_date) value ('A007','SQL2008','B006','F007','2007-06-12','2007-06-28');
insert into associate_status(Associate_id,Module_id,batch_id,trainer_id,Start_date,End_date) value ('A002','MSBI08','B007','F006','2009-6-26','2009-6-29');
insert into associate_status(Associate_id,Module_id,batch_id,trainer_id,Start_date,End_date) value ('A003','MSBI08','B007','F006','2009-6-26','2009-6-29');
insert into associate_status(Associate_id,Module_id,batch_id,trainer_id,Start_date,End_date) value ('A004','MSBI08','B007','F006','2009-6-26','2009-6-29');
insert into associate_status(Associate_id,Module_id,batch_id,trainer_id,Start_date,End_date) value ('A002','ANDRD4','B008','F005','2010-6-5','2010-6-28');
insert into associate_status(Associate_id,Module_id,batch_id,trainer_id,Start_date,End_date) value ('A005','ANDRD4','B008','F005','2010-6-5','2010-6-28');
insert into associate_status(Associate_id,Module_id,batch_id,trainer_id,Start_date,End_date) value ('A003','ANDRD4','B009','F005','2011-8-1','2011-8-20');
insert into associate_status(Associate_id,Module_id,batch_id,trainer_id,Start_date,End_date) value ('A006','ANDRD4','B009','F005','2011-8-1','2011-8-20');

use trainer_info;
update trainer_info
set trainer='nn4@123'
where trainer_id ='F004';


use associate_status;
delete from associate_status where associate_id='A003'and module_id ='J2EE';


use trainer_info;

select * from trainer_info;
select trainer_id,salutation,trainer_name,trainer_location,trainer_track,trainer_qualification,trainer_expirence,trainer_email,trainer
from trainer_info 
order by trainer_expirence
desc limit 1,5;

use login_details; 
start transaction;

insert into login_details values ('U001','Admin1@123');
insert into login_details values ('U002','Admin2@123');
rollback;


use login_details;

drop table login_details;

select* from login_details;



