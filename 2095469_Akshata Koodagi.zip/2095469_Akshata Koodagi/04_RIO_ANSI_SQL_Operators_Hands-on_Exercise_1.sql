-- #1
use trainer_info;
select * from trainer_info where trainer_email is null;

-- #2
select trainer_id, trainer_name, trainer_track, trainer_location from trainer_info where Trainer_Experiance>4;
-- #3
use module_info;
select * from module_info where Module_Duration>200;
-- #4
use trainer_info;
select trainer_id, trainer_name from trainer_info 
where trainer_qualification != 'Bachelor of Technology';
-- #5
use module_info;
select * from module_info where Module_Duration >= 200 and Module_Duration <= 300;
-- #6
use trainer_info;
select trainer_id , trainer_name from trainer_info where trainer_name like 'M%';

-- #7
select trainer_id, trainer_name from trainer_info where substring_index(trainer_name," ",1) like "%o%";

-- #8
use module_info;
select module_name from module_info where Module_Name is not null;