 -- problem 1#
 create database employee_id;
 use employee_id;
 create table student_info_(reg_number varchar(30),student_name_ varchar(30),branch varchar(30),contact_number varchar(10),
 date_of_birth varchar(20),date_of_joining varchar(20),address varchar(250),email_id varchar(250));
 
 create table subject_master(subject_code varchar(10),subject_name varchar(50),weightage int);
 
 create table student_marks(reg_number varchar(30),subject_code varchar(10),semester int, marks int);
 
 create table student_result(reg_number varchar(30),semester int,GPA int,Is_Eligible_Scholarship varchar(3));
 
 insert into student_info_ values ('MC101301','James','MCA','9714589787','1984-01-12','2010-07-8','NO 10,South Block,Nivea',
 'james.mca@yahoo.com');
  insert into student_info_ values ('BEC111402','Manio','ECE','8912457875','1983-02-23','2011-06-25','8/12, Park View,Sieera',
 'manioma@gmail.com');
  insert into student_info_ values ('BEEEI101204','Mike','EI','8974567897','1983-02-10','2010-08-25','Cross villa,NY',
 'mike.james@ymail.com');
  insert into student_info_ values ('MB111305','Paulson','MBA','8547986123','1984-12-193','2010-08-8','Lake View,NJ',
 'paul.son@rediffmail.com');
 
insert into subject_master values('EE01DFC','DCF',30);
insert into subject_master values('EC02MUP','Microprocessor',40);
insert into subject_master values('MC06DIP','Digital Image Processing',30);
insert into subject_master values('MB03MAR','Marketing Techniques',20);
insert into subject_master values('EI05IP','Instrumentation Precision',40);
insert into subject_master values('CPSC02DS','Data Structure',40);

insert into student_marks values('MC101301','EE01DFC',1,75);
insert into student_marks values('MC101301','EC02MUP',1,65);
insert into student_marks values('MC101301','MC06DIP',1,70); 
insert into student_marks values('BEC111402','EE01DFC',1,55); 
insert into student_marks values('BEC111402','EC02MUP',1,80); 
insert into student_marks values('BEC111402','MC06DIP',1,60); 
insert into student_marks values('BEEEI101204','EE01DFC',1,85); 
insert into student_marks values('BEEEI101204','EC02MUP',1,78); 
insert into student_marks values('BEEEI101204','MC06DIP',1,80); 
insert into student_marks values('BEEEI101204','MB03MAR',2,75); 
insert into student_marks values('BEEEI101204','EI05IP',2,65); 
insert into student_marks values('BEEEI101204','CPSC02DS',2,75); 
insert into student_marks values('MB111305','EE01DFC',1,65); 
insert into student_marks values('MB111305','EC02MUP',1,68); 
insert into student_marks values('MB111305','MC06DIP',1,63); 
insert into student_marks values('MB111305','MB03MAR',2,85); 
insert into student_marks values('MB111305','EI05IP',2,74); 
insert into student_marks values('MB111305','CPSC02DS',2,62); 

insert into student_result values('MC101301',1,7.5,'Y');
insert into student_result values('BEC111402',1,7.1,'Y'); 
insert into student_result values('BEEEI101204',1,8.3,'Y');
insert into student_result values('BEEEI101204',2,6.9,'N');
insert into student_result values('MB111305',1,6.5,'N');  
insert into student_result values('MB111305',2,6.8,'N');  

