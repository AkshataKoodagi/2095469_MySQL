
select upper(student_name_), upper(branch) from student_info_;


select lower(subject_code), lower(subject_name_), lower(weightage) from subject_master;


select reg_number, date_format(date_of_birth, '%M %d, %Y') from student_info_;


select student_name_, (period_diff(extract(year_month from current_date), extract(year_month from date_of_birth))/12)
 as age , contact_number,email_id from student_info_;


select reg_number, student_name_, 
(select avg(marks) from student_marks as smarks where smarks.Reg_Number = sinfo.Reg_Number) 
from student_info_ as sinfo;


select smarks.Reg_Number, sinfo.student_name_, max(marks) from student_info_ as sinfo
inner join student_marks as smarks on smarks.Reg_Number = sinfo.reg_number
group by smarks.subject_code;


select student_name_ , max(marks) from student_info_ as sinfo
inner join student_marks as smarks on sinfo.reg_number = smarks.reg_number
where subject_code = 'EI05IP';


select semester, avg(gpa) from student_result group by semester;


select student_name_, reg_number,branch, Contact_Number,Date_of_Birth,Date_of_Joining,Address,
case when Email_id is null then 'no valid email address'
else Email_id end as email_id   from student_info_;

