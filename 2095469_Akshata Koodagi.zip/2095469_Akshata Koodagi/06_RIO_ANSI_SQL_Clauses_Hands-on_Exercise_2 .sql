-- #1
use employee_id;
select sinfo.student_name, sinfo.reg_number, sresult.gpa from student_info as sinfo
inner join student_result as sresult on sresult.Reg_Number = sinfo.reg_number
 order by sresult.gpa desc;

-- #2
select * from student_info order by student_name asc;

-- #3
select * from student_info order by datediff(date_of_joining, date_of_birth) asc;

-- #4
select sinfo.reg_number, sinfo.student_name, semester, gpa from student_info as sinfo
inner join student_result as sresult on sresult.Reg_Number = sinfo.reg_number
order by sresult.gpa desc;

-- #5
select reg_number, gpa from student_result
order by Is_Eligible_Scholarship desc;


-- #6
select reg_number, gpa from student_result order by Is_Eligible_Scholarship desc;

-- #7
select * from student_info as sinfo
inner join student_result as sresult on sresult.reg_number = sinfo.reg_number
where sresult.gpa in (select  max(gpa) from student_result group by semester);

-- #8
select * from student_info as sinfo
inner join student_result as sresult on sresult.reg_number = sinfo.reg_number
where sresult.gpa in (select  min(gpa) from student_result group by semester);